# Konchi — Minecraft 1.21.1 (Forge) uchun mod

Funksiyalar (menyu: **o'ng Shift**): Fullbright, rudalar, sandiqlar, o'yinchilar, ruda radiusi 16–128 blok.
Sozlamalar `config/konchi.properties` fayliga saqlanadi.

## .jar ni yig'ish (GitHub orqali)
1. Yangi repozitoriy oching (masalan `konchi-forge`) va shu papkadagi fayllarni yuklang.
2. `.github/workflows/build.yml` tushmay qolsa, uni qo'lda yarating.
3. **Actions** bo'limida build tugagach, **Artifacts** dan `konchi-1.0.0.jar` ni oling.

## O'rnatish
Forge **1.21.1** (52.1.0 yoki yangiroq) o'rnating va `konchi-1.0.0.jar` ni `mods` papkasiga tashlang.
Forge uchun Fabric API kerak emas.
