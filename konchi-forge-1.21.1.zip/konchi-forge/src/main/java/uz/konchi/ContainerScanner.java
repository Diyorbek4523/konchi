package uz.konchi;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

/** Atrofdagi yuklangan chunk'lardan sandiq, bochka va shulker qutilarini topadi. */
public final class ContainerScanner {
	/** Topilgan konteyner: joyi va ender sandig'imi. */
	public record Container(BlockPos pos, boolean ender) {
	}

	/** Qidiruv radiusi chunk'larda (4 chunk = 64 blok). */
	private static final int CHUNK_RADIUS = 4;
	private static final int INTERVAL_TICKS = 20;

	private static volatile List<Container> results = List.of();
	private static int timer;

	private ContainerScanner() {
	}

	public static List<Container> results() {
		return results;
	}

	public static void tick(Minecraft client) {
		ClientLevel level = client.level;

		if (!Settings.containers || level == null || client.player == null) {
			results = List.of();
			timer = 0;
			return;
		}

		if (timer-- > 0) {
			return;
		}

		timer = INTERVAL_TICKS;
		List<Container> found = new ArrayList<>();
		int pcx = client.player.blockPosition().getX() >> 4;
		int pcz = client.player.blockPosition().getZ() >> 4;

		for (int cx = pcx - CHUNK_RADIUS; cx <= pcx + CHUNK_RADIUS; cx++) {
			for (int cz = pcz - CHUNK_RADIUS; cz <= pcz + CHUNK_RADIUS; cz++) {
				if (!level.hasChunk(cx, cz)) {
					continue;
				}

				LevelChunk chunk = level.getChunk(cx, cz);

				for (BlockEntity be : chunk.getBlockEntities().values()) {
					if (be instanceof EnderChestBlockEntity) {
						found.add(new Container(be.getBlockPos(), true));
					} else if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity) {
						found.add(new Container(be.getBlockPos(), false));
					}
				}
			}
		}

		results = List.copyOf(found);
	}
}
