package uz.konchi;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;

/** Devor orqali ko'rinadigan shaffof qutilarni chizadi (Minecraft 1.21.1). */
public final class EspRenderer {
	private static final float ALPHA = 0.35f;
	private static final int CONTAINER_COLOR = 0xFFFF9900;
	private static final int ENDER_COLOR = 0xFFAA00FF;
	private static final int PLAYER_COLOR = 0xFFFF3355;

	private static final Vector3f TMP = new Vector3f();

	private static BufferBuilder buffer;
	private static Matrix4f pose;
	private static double camX, camY, camZ;

	private EspRenderer() {
	}

	public static void onRenderLevel(RenderLevelStageEvent event) {
		if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) {
			return;
		}

		Minecraft client = Minecraft.getInstance();

		if (client.level == null || client.player == null) {
			return;
		}

		if (!Settings.ores && !Settings.containers && !Settings.players) {
			return;
		}

		Vec3 cam = event.getCamera().getPosition();
		camX = cam.x;
		camY = cam.y;
		camZ = cam.z;
		pose = event.getPoseStack();
		buffer = null;

		if (Settings.ores) {
			for (OreScanner.Ore ore : OreScanner.results()) {
				BlockPos p = ore.pos();

				// Rudani qazib olgan bo'lsangiz, chizmaymiz.
				if (client.level.getBlockState(p).isAir()) {
					continue;
				}

				box(p.getX() + 0.1, p.getY() + 0.1, p.getZ() + 0.1, p.getX() + 0.9, p.getY() + 0.9, p.getZ() + 0.9, ore.color());
			}
		}

		if (Settings.containers) {
			for (ContainerScanner.Container c : ContainerScanner.results()) {
				BlockPos p = c.pos();
				box(p.getX() + 0.0625, p.getY(), p.getZ() + 0.0625, p.getX() + 0.9375, p.getY() + 0.875, p.getZ() + 0.9375, c.ender() ? ENDER_COLOR : CONTAINER_COLOR);
			}
		}

		if (Settings.players) {
			float pt = event.getPartialTick();

			for (AbstractClientPlayer other : client.level.players()) {
				if (other == client.player || other.isRemoved()) {
					continue;
				}

				double x = Mth.lerp(pt, other.xo, other.getX());
				double y = Mth.lerp(pt, other.yo, other.getY());
				double z = Mth.lerp(pt, other.zo, other.getZ());
				double hw = other.getBbWidth() / 2.0;
				box(x - hw, y, z - hw, x + hw, y + other.getBbHeight(), z + hw, PLAYER_COLOR);
			}
		}

		if (buffer == null) {
			return;
		}

		MeshData mesh = buffer.build();
		buffer = null;

		if (mesh == null) {
			return;
		}

		RenderSystem.setShader(GameRenderer::getPositionColorShader);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableCull();
		RenderSystem.disableDepthTest();
		RenderSystem.depthMask(false);

		BufferUploader.drawWithShader(mesh);

		RenderSystem.depthMask(true);
		RenderSystem.enableDepthTest();
		RenderSystem.enableCull();
		RenderSystem.disableBlend();
	}

	private static void box(double x1d, double y1d, double z1d, double x2d, double y2d, double z2d, int argb) {
		if (buffer == null) {
			buffer = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
		}

		// Kamera atrofidagi koordinatalar (katta sonlarda aniqlik yo'qolmasligi uchun)
		float x1 = (float) (x1d - camX), y1 = (float) (y1d - camY), z1 = (float) (z1d - camZ);
		float x2 = (float) (x2d - camX), y2 = (float) (y2d - camY), z2 = (float) (z2d - camZ);
		float r = ((argb >> 16) & 0xFF) / 255f;
		float g = ((argb >> 8) & 0xFF) / 255f;
		float b = (argb & 0xFF) / 255f;

		// Old
		v(x1, y1, z2, r, g, b); v(x2, y1, z2, r, g, b); v(x2, y2, z2, r, g, b); v(x1, y2, z2, r, g, b);
		// Orqa
		v(x2, y1, z1, r, g, b); v(x1, y1, z1, r, g, b); v(x1, y2, z1, r, g, b); v(x2, y2, z1, r, g, b);
		// Chap
		v(x1, y1, z1, r, g, b); v(x1, y1, z2, r, g, b); v(x1, y2, z2, r, g, b); v(x1, y2, z1, r, g, b);
		// O'ng
		v(x2, y1, z2, r, g, b); v(x2, y1, z1, r, g, b); v(x2, y2, z1, r, g, b); v(x2, y2, z2, r, g, b);
		// Tepa
		v(x1, y2, z2, r, g, b); v(x2, y2, z2, r, g, b); v(x2, y2, z1, r, g, b); v(x1, y2, z1, r, g, b);
		// Past
		v(x1, y1, z1, r, g, b); v(x2, y1, z1, r, g, b); v(x2, y1, z2, r, g, b); v(x1, y1, z2, r, g, b);
	}

	private static void v(float x, float y, float z, float r, float g, float b) {
		pose.transformPosition(x, y, z, TMP);
		buffer.addVertex(TMP.x, TMP.y, TMP.z).setColor(r, g, b, ALPHA);
	}
}
