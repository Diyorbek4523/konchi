package uz.konchi;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;

@Mod(Konchi.MOD_ID)
public class Konchi {
	public static final String MOD_ID = "konchi";
	public static final Logger LOGGER = LogUtils.getLogger();

	@SuppressWarnings("removal")
	public Konchi() {
		// Mod faqat o'yinchi tomonida (client) ishlaydi.
		if (FMLEnvironment.dist == Dist.CLIENT) {
			KonchiClient.init(FMLJavaModLoadingContext.get().getModEventBus());
		}
	}
}
