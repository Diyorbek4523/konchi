package uz.konchi;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;

public final class KonchiClient {
	private static final KeyMapping MENU_KEY = new KeyMapping(
			"key.konchi.menu",
			InputConstants.Type.KEYSYM,
			InputConstants.KEY_RSHIFT,
			"key.categories.konchi"
	);

	/** Tungi ko'rish effektini biz qo'yganmizmi. */
	private static boolean fullbrightApplied = false;

	private KonchiClient() {
	}

	public static void init(IEventBus modBus) {
		Settings.load();
		modBus.addListener(KonchiClient::onRegisterKeys);
		MinecraftForge.EVENT_BUS.addListener(KonchiClient::onClientTick);
		MinecraftForge.EVENT_BUS.addListener(EspRenderer::onRenderLevel);
	}

	private static void onRegisterKeys(RegisterKeyMappingsEvent event) {
		event.register(MENU_KEY);
	}

	private static void onClientTick(TickEvent.ClientTickEvent.Post event) {
		Minecraft client = Minecraft.getInstance();

		while (MENU_KEY.consumeClick()) {
			if (client.screen == null) {
				client.setScreen(new KonchiScreen());
			}
		}

		updateFullbright(client.player);
		OreScanner.tick(client);
		ContainerScanner.tick(client);
	}

	/** Fullbright: o'yinchiga faqat o'zingiz ko'radigan tungi ko'rish effektini beradi. */
	private static void updateFullbright(LocalPlayer player) {
		if (player == null) {
			fullbrightApplied = false;
			return;
		}

		if (Settings.fullbright) {
			if (!player.hasEffect(MobEffects.NIGHT_VISION)) {
				player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
				fullbrightApplied = true;
			}
		} else if (fullbrightApplied) {
			player.removeEffect(MobEffects.NIGHT_VISION);
			fullbrightApplied = false;
		}
	}
}
